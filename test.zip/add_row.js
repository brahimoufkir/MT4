const fs = require('fs');

try {
    // read contents of the file
    const data = fs.readFileSync('out.csv', 'UTF-8');

    newdata = "test__V2.02.00.ff_\n"+ data
	
	fs.writeFile('out.csv', newdata, function (err) {
    if (err) {
    // append failed
		
    } else {
    // done
    }
    })
} catch (err) {
    console.error(err);
}